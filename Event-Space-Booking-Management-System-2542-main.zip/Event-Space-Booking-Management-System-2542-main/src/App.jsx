import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { StoreProvider } from './context/StoreContext';
import Navbar from './components/layout/Navbar';
import MobileNav from './components/layout/MobileNav';
import Home from './pages/Home';
import BookingWizard from './pages/customer/BookingWizard';
import AdminDashboard from './pages/admin/AdminDashboard';
import BookingsList from './pages/admin/BookingsList';
import AdminCalendar from './pages/admin/AdminCalendar';
import EventTypesManager from './pages/admin/EventTypesManager';
import PricingRulesManager from './pages/admin/PricingRulesManager';
import AddOnsManager from './pages/admin/AddOnsManager';
import Settings from './pages/admin/Settings';

function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <div className="min-h-screen bg-[var(--color-bg-page)] text-[var(--color-text-main)] flex flex-col">
          {/* Top Navigation for Desktop */}
          <Navbar />
          
          {/* Main Content Area */}
          <main className="flex-1 w-full">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/widget" element={<BookingWizard />} />
              <Route path="/booking" element={<BookingWizard />} />
              
              {/* Admin Routes */}
              <Route path="/admin" element={<Navigate to="/admin/dashboard" />} />
              <Route path="/admin/dashboard" element={<AdminDashboard />} />
              <Route path="/admin/bookings" element={<BookingsList />} />
              <Route path="/admin/calendar" element={<AdminCalendar />} />
              <Route path="/admin/event-types" element={<EventTypesManager />} />
              <Route path="/admin/pricing-rules" element={<PricingRulesManager />} />
              <Route path="/admin/addons" element={<AddOnsManager />} />
              <Route path="/admin/settings" element={<Settings />} />
            </Routes>
          </main>
          
          {/* Bottom Navigation for Mobile */}
          <MobileNav />
        </div>
      </BrowserRouter>
    </StoreProvider>
  );
}

export default App;