import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../../common/SafeIcon';
import { cn } from '../../lib/utils';

const MobileNav = () => {
  const location = useLocation();
  const [showMore, setShowMore] = useState(false);
  const isAdmin = location.pathname.startsWith('/admin');

  if (location.pathname === '/' || location.pathname.includes('/widget')) return null;

  const userLinks = [
    { path: '/booking', icon: FiIcons.FiCalendar, label: 'Book' },
    { path: '/', icon: FiIcons.FiHome, label: 'Home' },
  ];

  const adminMainLinks = [
    { path: '/admin/dashboard', icon: FiIcons.FiGrid, label: 'Dash' },
    { path: '/admin/bookings', icon: FiIcons.FiInbox, label: 'Requests' },
    { path: '/admin/calendar', icon: FiIcons.FiCalendar, label: 'Calendar' },
  ];

  const adminMoreLinks = [
    { path: '/admin/event-types', icon: FiIcons.FiTag, label: 'Event Types' },
    { path: '/admin/pricing-rules', icon: FiIcons.FiDollarSign, label: 'Pricing' },
    { path: '/admin/addons', icon: FiIcons.FiPackage, label: 'Add-ons' },
    { path: '/admin/settings', icon: FiIcons.FiSettings, label: 'Settings' },
  ];

  const links = isAdmin ? [...adminMainLinks, { action: 'more', icon: FiIcons.FiMoreHorizontal, label: 'More' }] : userLinks;

  return (
    <>
      {/* More Menu Overlay */}
      {showMore && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden" onClick={() => setShowMore(false)}>
          <div className="absolute bottom-16 left-0 right-0 bg-white rounded-t-2xl shadow-2xl p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4 pb-3 border-b border-gray-200">
              <h3 className="font-bold text-gray-900">More Options</h3>
              <button onClick={() => setShowMore(false)} className="text-gray-400 hover:text-gray-600">
                <SafeIcon icon={FiIcons.FiX} className="text-xl" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {adminMoreLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setShowMore(false)}
                  className={cn(
                    "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-colors",
                    location.pathname === link.path
                      ? "border-primary bg-blue-50 text-primary"
                      : "border-gray-200 text-gray-600 hover:border-primary hover:bg-blue-50"
                  )}
                >
                  <SafeIcon icon={link.icon} className="text-2xl" />
                  <span className="text-xs font-medium">{link.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 flex justify-around items-center z-50 safe-area-bottom md:hidden shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
        {links.map((link) => {
          if (link.action === 'more') {
            return (
              <button
                key="more"
                onClick={() => setShowMore(true)}
                className="flex flex-col items-center gap-1 p-2 rounded-lg transition-colors min-w-[64px] text-gray-500 hover:text-gray-900"
              >
                <SafeIcon icon={link.icon} className="text-2xl mb-0.5" />
                <span className="text-[10px] font-medium tracking-wide">{link.label}</span>
              </button>
            );
          }
          return (
            <Link
              key={link.path}
              to={link.path}
              className={cn(
                "flex flex-col items-center gap-1 p-2 rounded-lg transition-colors min-w-[64px]",
                location.pathname === link.path ? "text-primary font-bold" : "text-gray-500 hover:text-gray-900"
              )}
            >
              <SafeIcon icon={link.icon} className="text-2xl mb-0.5" />
              <span className="text-[10px] font-medium tracking-wide">{link.label}</span>
            </Link>
          );
        })}
      </div>
    </>
  );
};

export default MobileNav;