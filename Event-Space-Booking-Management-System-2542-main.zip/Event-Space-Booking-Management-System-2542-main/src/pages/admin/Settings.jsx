import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Button } from '../../components/ui/Button';
import * as FiIcons from 'react-icons/fi';
import SafeIcon from '../../common/SafeIcon';
import { cn } from '../../lib/utils';

const Settings = () => {
  const { settings, updateSettings } = useStore();
  const [activeTab, setActiveTab] = useState('branding');
  const [formData, setFormData] = useState(settings);
  const [isSaved, setIsSaved] = useState(false);

  // Derive the base URL for embed codes
  const appUrl = window.location.origin;

  const handleSave = () => {
    updateSettings(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('Embed code copied to clipboard!');
  };

  const bookingEmbedCode = `<iframe src="${appUrl}/booking" style="width:100%; height:700px; border:none; border-radius:12px; overflow:hidden;"></iframe>`;
  
  const calendarEmbedCode = `<iframe src="${appUrl}/admin/calendar" style="width:100%; height:900px; border:none; border-radius:12px; overflow:hidden;"></iframe>`;

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto pb-24">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        {activeTab !== 'embed' && (
          <Button 
            onClick={handleSave} 
            className={cn("transition-all", isSaved ? "bg-green-600 hover:bg-green-700" : "")}
          >
            {isSaved ? (
              <>
                <SafeIcon icon={FiIcons.FiCheck} className="mr-2" />
                Saved Changes
              </>
            ) : 'Save Changes'}
          </Button>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('branding')}
            className={cn(
              "px-6 py-4 text-sm font-bold transition-colors flex items-center gap-2",
              activeTab === 'branding' 
                ? "text-primary border-b-2 border-primary bg-blue-50/50" 
                : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <SafeIcon icon={FiIcons.FiDroplet} />
            Branding
          </button>
          <button
            onClick={() => setActiveTab('policies')}
            className={cn(
              "px-6 py-4 text-sm font-bold transition-colors flex items-center gap-2",
              activeTab === 'policies' 
                ? "text-primary border-b-2 border-primary bg-blue-50/50" 
                : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <SafeIcon icon={FiIcons.FiFileText} />
            Rental Policies
          </button>
          <button
            onClick={() => setActiveTab('embed')}
            className={cn(
              "px-6 py-4 text-sm font-bold transition-colors flex items-center gap-2",
              activeTab === 'embed' 
                ? "text-primary border-b-2 border-primary bg-blue-50/50" 
                : "text-gray-600 hover:bg-gray-50"
            )}
          >
            <SafeIcon icon={FiIcons.FiCode} />
            Embed Code
          </button>
        </div>

        <div className="p-6 md:p-8">
          {activeTab === 'branding' && (
            <div className="space-y-6 max-w-lg">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Company Name</label>
                <input
                  type="text"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary outline-none"
                  value={formData.companyName}
                  onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Primary Color</label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      className="h-10 w-10 rounded cursor-pointer border border-gray-300 p-0.5"
                      value={formData.primaryColor}
                      onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                    />
                    <input
                      type="text"
                      className="flex-1 p-2 border border-gray-300 rounded-lg font-mono text-sm uppercase"
                      value={formData.primaryColor}
                      onChange={(e) => setFormData({ ...formData, primaryColor: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Accent Color</label>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      className="h-10 w-10 rounded cursor-pointer border border-gray-300 p-0.5"
                      value={formData.accentColor}
                      onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                    />
                    <input
                      type="text"
                      className="flex-1 p-2 border border-gray-300 rounded-lg font-mono text-sm uppercase"
                      value={formData.accentColor}
                      onChange={(e) => setFormData({ ...formData, accentColor: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'policies' && (
            <div className="space-y-6">
              <div className="p-4 bg-blue-50 text-blue-900 rounded-lg text-sm border border-blue-100 flex gap-3">
                <SafeIcon icon={FiIcons.FiInfo} className="mt-0.5" />
                <p>These policies will be displayed to customers during the booking process. They must agree to them before submitting a request.</p>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Booking & Payment Terms</label>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-lg h-32 focus:ring-2 focus:ring-primary outline-none"
                  value={formData.rentalPolicies?.payment || ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    rentalPolicies: { ...formData.rentalPolicies, payment: e.target.value } 
                  })}
                  placeholder="Enter payment terms, deposit requirements, etc."
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Cancellation Policy</label>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-lg h-32 focus:ring-2 focus:ring-primary outline-none"
                  value={formData.rentalPolicies?.cancellation || ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    rentalPolicies: { ...formData.rentalPolicies, cancellation: e.target.value } 
                  })}
                  placeholder="Enter cancellation rules and refund policies."
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Liability & Insurance</label>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-lg h-24 focus:ring-2 focus:ring-primary outline-none"
                  value={formData.rentalPolicies?.liability || ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    rentalPolicies: { ...formData.rentalPolicies, liability: e.target.value } 
                  })}
                  placeholder="Enter liability and insurance requirements."
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Setup & Cleanup</label>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-lg h-24 focus:ring-2 focus:ring-primary outline-none"
                  value={formData.rentalPolicies?.cleanup || ''}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    rentalPolicies: { ...formData.rentalPolicies, cleanup: e.target.value } 
                  })}
                  placeholder="Enter setup and cleanup expectations."
                />
              </div>
            </div>
          )}

          {activeTab === 'embed' && (
            <div className="space-y-8">
              {/* Customer Booking Widget */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold text-gray-900">Customer Booking Widget</h3>
                  <span className="bg-green-100 text-green-800 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">Public</span>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Embed this widget on your public website to allow customers to book events.
                </p>
                <div className="relative group">
                  <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm font-mono overflow-x-auto whitespace-pre-wrap break-all">
                    {bookingEmbedCode}
                  </pre>
                  <button
                    onClick={() => copyToClipboard(bookingEmbedCode)}
                    className="absolute top-2 right-2 bg-white text-gray-900 px-3 py-1.5 rounded-md text-xs font-bold shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-100"
                  >
                    Copy Code
                  </button>
                </div>
              </div>

              <hr className="border-gray-200" />

              {/* Admin Calendar Widget */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-bold text-gray-900">Admin Calendar Widget</h3>
                  <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded uppercase tracking-wider">Admin Only</span>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Embed this widget in your admin dashboard or internal tools to manage bookings.
                  <br />
                  <span className="text-primary font-medium flex items-center gap-1 mt-1">
                    <SafeIcon icon={FiIcons.FiInfo} className="inline" /> 
                    Includes calendar view, event management, and blocking capabilities.
                  </span>
                </p>
                <div className="relative group">
                  <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm font-mono overflow-x-auto whitespace-pre-wrap break-all">
                    {calendarEmbedCode}
                  </pre>
                  <button
                    onClick={() => copyToClipboard(calendarEmbedCode)}
                    className="absolute top-2 right-2 bg-white text-gray-900 px-3 py-1.5 rounded-md text-xs font-bold shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-100"
                  >
                    Copy Code
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;