import React, { createContext, useContext, useState, useEffect } from 'react';
import { generateId } from '../lib/utils';

const StoreContext = createContext();

const INITIAL_EVENT_TYPES = [
  { 
    id: 'evt_1', 
    name: 'Wedding Reception', 
    description: 'Full venue access for your special day', 
    baseRate: 200, 
    minDuration: 4, 
    active: true,
    cooldownHours: 1,
    emailTemplates: {
      confirmationAlias: '',
      followUpAlias: ''
    }
  },
  { 
    id: 'evt_2', 
    name: 'Corporate Event', 
    description: 'Professional setting for meetings', 
    baseRate: 150, 
    minDuration: 2, 
    active: true,
    cooldownHours: 1,
    emailTemplates: {
      confirmationAlias: '',
      followUpAlias: ''
    }
  },
  { 
    id: 'evt_3', 
    name: 'Photo Shoot', 
    description: 'Hourly rental for photographers', 
    baseRate: 75, 
    minDuration: 1, 
    active: true,
    cooldownHours: 1,
    emailTemplates: {
      confirmationAlias: '',
      followUpAlias: ''
    }
  },
];

const INITIAL_RULES = [
  { id: 'rule_1', name: 'Weekend Peak', eventTypeId: null, days: [0, 5, 6], startTime: '12:00', endTime: '23:59', hourlyRate: 250 },
  { id: 'rule_2', name: 'Weekday Morning Discount', eventTypeId: 'evt_2', days: [1, 2, 3, 4], startTime: '08:00', endTime: '12:00', hourlyRate: 100 },
];

const INITIAL_ADDONS = [
  { id: 'add_1', name: 'Projector & Screen', description: 'High definition projection', price: 50, type: 'flat', active: true, eventTypeIds: ['evt_2', 'evt_3'] },
  { id: 'add_2', name: 'Catering Setup', description: 'Tables and linens for food', price: 100, type: 'flat', active: true, eventTypeIds: ['evt_1', 'evt_2'] },
  { id: 'add_3', name: 'Security Guard', description: 'Required for alcohol events', price: 40, type: 'hourly', active: true, eventTypeIds: ['evt_1'] },
];

export function StoreProvider({ children }) {
  const [eventTypes, setEventTypes] = useState(() => {
    const saved = localStorage.getItem('eventTypes');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Migrate old event types that don't have emailTemplates or cooldownHours
      return parsed.map(eventType => ({
        ...eventType,
        cooldownHours: eventType.cooldownHours ?? 1, // Default to 1 hour
        emailTemplates: eventType.emailTemplates || {
          confirmationAlias: '',
          followUpAlias: ''
        }
      }));
    }
    return INITIAL_EVENT_TYPES;
  });

  const [pricingRules, setPricingRules] = useState(() => {
    const saved = localStorage.getItem('pricingRules');
    return saved ? JSON.parse(saved) : INITIAL_RULES;
  });

  const [bookings, setBookings] = useState(() => {
    const saved = localStorage.getItem('bookings');
    return saved ? JSON.parse(saved) : [];
  });

  const [blockedDates, setBlockedDates] = useState(() => {
    const saved = localStorage.getItem('blockedDates');
    return saved ? JSON.parse(saved) : [];
  });

  const [addOns, setAddOns] = useState(() => {
    const saved = localStorage.getItem('addOns');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Migrate old add-ons that don't have eventTypeIds
      return parsed.map(addon => ({
        ...addon,
        eventTypeIds: addon.eventTypeIds || [] // Empty array means available for all event types
      }));
    }
    return INITIAL_ADDONS;
  });

  const [settings, setSettings] = useState(() => {
    const saved = localStorage.getItem('settings');
    const defaultSettings = {
      primaryColor: '#1d4ed8',
      accentColor: '#7c3aed',
      companyName: 'Luxe Events',
    };
    
    if (!saved) return defaultSettings;
    
    const parsed = JSON.parse(saved);
    if (parsed.primaryColor === '#3b82f6') {
      return { ...parsed, primaryColor: '#1d4ed8' };
    }
    return parsed;
  });

  useEffect(() => {
    if (settings.primaryColor) {
      document.documentElement.style.setProperty('--color-primary', settings.primaryColor);
    }
    if (settings.accentColor) {
      document.documentElement.style.setProperty('--color-accent', settings.accentColor);
    }
  }, [settings]);

  useEffect(() => localStorage.setItem('eventTypes', JSON.stringify(eventTypes)), [eventTypes]);
  useEffect(() => localStorage.setItem('pricingRules', JSON.stringify(pricingRules)), [pricingRules]);
  useEffect(() => localStorage.setItem('bookings', JSON.stringify(bookings)), [bookings]);
  useEffect(() => localStorage.setItem('blockedDates', JSON.stringify(blockedDates)), [blockedDates]);
  useEffect(() => localStorage.setItem('addOns', JSON.stringify(addOns)), [addOns]);
  useEffect(() => localStorage.setItem('settings', JSON.stringify(settings)), [settings]);

  const addBooking = (booking) => {
    const newBooking = { ...booking, id: generateId(), status: 'pending', createdAt: new Date().toISOString() };
    setBookings([...bookings, newBooking]);
    return newBooking;
  };

  const updateBookingStatus = (id, status) => {
    setBookings(bookings.map(b => b.id === id ? { ...b, status } : b));
  };

  // New function to update full booking details
  const updateBookingDetails = (updatedBooking) => {
    setBookings(bookings.map(b => b.id === updatedBooking.id ? updatedBooking : b));
  };

  const addBlockedDate = (date, reason = 'Manually Blocked', startTime = null, endTime = null) => {
    // Check if blocking specific time slot or full day
    const blockData = {
      id: generateId(),
      date,
      reason,
      isFullDay: !startTime && !endTime,
      startTime,
      endTime
    };
    
    setBlockedDates([...blockedDates, blockData]);
  };

  const removeBlockedDate = (id) => {
    setBlockedDates(blockedDates.filter(d => d.id !== id));
  };

  const updateSettings = (newSettings) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const getAddOnsForEventType = (eventTypeId) => {
    return addOns.filter(addon => {
      if (!addon.active) return false;
      if (!addon.eventTypeIds || addon.eventTypeIds.length === 0) return true;
      return addon.eventTypeIds.includes(eventTypeId);
    });
  };

  // Get confirmed bookings for a specific date
  const getBookingsForDate = (date) => {
    return bookings.filter(booking => {
      if (booking.status === 'declined' || booking.status === 'cancelled') return false;
      return booking.date === date;
    });
  };

  // Get blocked time slots for a specific date
  const getBlockedTimesForDate = (date) => {
    return blockedDates.filter(block => block.date === date);
  };

  return (
    <StoreContext.Provider value={{
      eventTypes, setEventTypes,
      pricingRules, setPricingRules,
      bookings, addBooking, updateBookingStatus, updateBookingDetails, getBookingsForDate,
      blockedDates, addBlockedDate, removeBlockedDate, getBlockedTimesForDate,
      addOns, setAddOns, getAddOnsForEventType,
      settings, updateSettings
    }}>
      {children}
    </StoreContext.Provider>
  );
}

export const useStore = () => useContext(StoreContext);